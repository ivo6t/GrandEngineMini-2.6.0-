import pygame
from game_engine.core import GN

class player:
    class input:
        @staticmethod
        def GNInput(x,y,speed):
            GN.input.get()

            if GN.input.up(): y -= speed
            if GN.input.down(): y += speed
            if GN.input.left(): x -= speed
            if GN.input.right(): x += speed

            return x,y