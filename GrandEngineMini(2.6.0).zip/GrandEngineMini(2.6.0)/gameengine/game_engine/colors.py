import pygame

class Colors:
    @staticmethod
    def red():
        return (255,0,0)
    @staticmethod
    def green():
        return (0,255,0)
    @staticmethod
    def blue():
        return (0,0,255)
    @staticmethod
    def white():
        return (255,255,255)
    @staticmethod
    def black():
        return (0,0,0)
    @staticmethod
    def yellow():
        return (255,255,0)
    @staticmethod
    def cyan():
        return (0,255,255)
    @staticmethod
    def magenta():
        return (255,0,255)
    @staticmethod
    def dark_blue():
        return (0,0,102)
    @staticmethod
    def pink():
        return (255,153,153)
    @staticmethod
    def purple():
        return (102,0,204)
    @staticmethod
    def orange():
        return (255,128,0)
    @staticmethod
    def navy():
        return (0,0,128)