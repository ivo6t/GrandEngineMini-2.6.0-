import pygame
import time

class Memes:
    @staticmethod
    def crash():
        return 0
    @staticmethod
    def spotify():
        print("spotify is best which ...")
        time.sleep(1)
        print("vsc")
    @staticmethod
    def comparisment():
        print("godot is 50mb...")
        time.sleep(1)
        print("GrandEngineMini is 20kb...")
        time.sleep(1)
        print("and unity is 50gb")
        time.sleep(1)
        print("GrandEngineMini wins")