from game_engine.core import *
import time

class Player:
    def __init__(self, x, y):
        self.x = x
        self.y = y
class Input:
    @staticmethod
    def jump(player,h):
        player.y -= h
        time.sleep(0.2)
        player.y += h
    @staticmethod
    def running(player,speed):
        GN.input.get()
        if GN.input.up():
           player.y -= speed*2 
        if GN.input.down():
            player.y += speed*2
        if GN.input.left():
            player.x -= speed*2
        if GN.input.right():
            player.x += speed*2