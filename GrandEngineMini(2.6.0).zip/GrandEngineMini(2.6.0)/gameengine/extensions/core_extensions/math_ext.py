import math
import pygame

class Math:
    def vel_calc(distance,time):
        return distance / time
    @staticmethod
    def Eul(y,x,h,f):
        """
        One step of Euler’s Method
        x: current x
        y: current y
        h: step size
        f: derivative function dy/dx = f(x, y)
        """
        return y + h * f(x,y)