class Krisko:
    @staticmethod
    def wild():
        print("""Uh, you going to the store?
Grab some Victory or whatever
From the internet, ‘cause I got a Skype date, hahaha
Oh, wait, wait, grab one regular Pomorie too
‘Cause you never know, bro (haha-haha)
Aight, the last one closes the door
They caught us without pants (crazy stuff)
Do your folks know? (What y’all doing?)
No wild passion, the white became like “what’s up”
Stay for lunch, there’s sweet drinks, p***ies with mustaches in braids
Move them away, I want young brides, got icicles from the coke on your nose
A white Mercedes chasin’ me through life
White, white powder enters my nose, through a bill
At this point I’m a baked kebab
The chaos is only in your head, bro, it’s all rap
This stuff with toilets in clubs is awkward
Make a nose fun salon
When we’re by the sea, we’re tourists
When we’re drinkin’ at the table, we’re communists (cheers)
You’re a senior, I’m hitting the prom circuit
They know me at all the bars
I don’t sing sad songs, ‘cause my life ain’t fed
I go to parties super lit
Stay for lunch, there’s sweet drinks
P***ies with mustaches in braids
Yo don’t touch me, that s** nasty
Krisko bro, you got taste
They caught us without pants (crazy stuff)
Do your folks know? (What y’all doing?)
No wild passion, the white became like “what’s up”
Stay for lunch, there’s sweet drinks, p***ies with mustaches in braids
Move them away, I want young brides, got icicles from the coke on your nose
You wanna make love on your Skype?
If you’re 12, bring your mama too
It’s Friday, so I’ma be toxic
In two days I crash, lookin’ unfriendly
Me and my crew finna become bosses
All day puffin’ white Victory
I bump Serbian, keep it lowkey
Sometimes I mix Rihanna with Rayna
Rapper listenin’ to Zhivko Mix and Maria
Why you lookin’ at me like a lame bug in horse crap?
Bro I’m a fan only of the Cossacks and Stalin
In the taverns they know me as a disco partisan
I pull out the white, bro, and we make dough
Two, three, four – all the way to 100
Krisko and Kilata, the hip-hop dream team
Snortin’ coke in the GymBeam
They caught us without pants (crazy stuff)
Do your folks know? (What y’all doing?)
No wild passion, the white became like “what’s up”
Stay for lunch, there’s sweet drinks, p***ies with mustaches in braids
Move them away, I want young brides, got icicles from the coke on your nose
At one point we thought to stop
Say something, but who stands in front of a freight train?
Run, it’s comin’ back
You act tough but watch porn
Don’t tire me out, go do your school test
Should I slap you? You too damn small
I’ll give your teeth some tartar raw
Uncle, your bag of jokes run out?
They don’t let you in Sofia? Go back to Kardzhali
It’s full of bench-warmers, wankers, underpass creeps
I’m drivin’ a Golf, brand new like Milen Tsvetkov
Sometimes around me it’s straight cannibalism
I’ma eat all the p***ies from the tourism high school
Bro, it’s Saturday, gotta sit at the table – tradition
If I don’t drink 5 rakias, I’ll call the police
Damn you nasty (you freak)
Nasty, but you lovin’ the white – ask Volen
Don Baro where your chains, your Benzes at?
You the shaman of the shipwrecked
They caught us without pants (crazy stuff)
Do your folks know? (What y’all doing?)
No wild passion, the white became like “what’s up”
Stay for lunch, there’s sweet drinks, p***ies with mustaches in braids
Move them away, I want young brides, got icicles from the coke on your nose
They caught us without pants (crazy stuff)
Do your folks know? (What y’all doing?)
No wild passion, the white became like “what’s up”
Stay for lunch, there’s sweet drinks, p***ies with mustaches in braids
Move them away, I want young brides, got icicles from the coke on your nose
""")
