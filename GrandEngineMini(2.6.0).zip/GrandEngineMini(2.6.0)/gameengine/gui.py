import tkinter as tk
from tkinter import scrolledtext
import os
import subprocess
from game_engine.core import all

# Folder to save user scripts
SCRIPT_FOLDER = "scripts"
os.makedirs(SCRIPT_FOLDER, exist_ok=True)

class ScriptEditor:
    def __init__(self, root):
        self.root = root
        root.title("Game Engine Script Editor")

        # Text area for code
        self.text_area = scrolledtext.ScrolledText(root, width=60, height=20)
        self.text_area.pack(padx=10, pady=10)

        # Buttons frame
        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=5)

        # Create new file button
        self.new_btn = tk.Button(btn_frame, text="New Script", command=self.create_new_script)
        self.new_btn.pack(side=tk.LEFT, padx=5)

        # Run code button
        self.run_btn = tk.Button(btn_frame, text="Run Script", command=self.run_script)
        self.run_btn.pack(side=tk.LEFT, padx=5)

        # Currently loaded file name
        self.current_file = None

    def create_new_script(self):
        # Create a new empty script file with default name
        new_file_name = os.path.join(SCRIPT_FOLDER, "user_script.py")
        with open(new_file_name, "w") as f:
            f.write("# Write your script here\n")
        self.current_file = new_file_name
        # Load into text area
        self.load_script(new_file_name)

    def load_script(self, filepath):
        with open(filepath, "r") as f:
            content = f.read()
        self.text_area.delete(1.0, tk.END)
        self.text_area.insert(tk.END, content)

    def save_script(self):
        if self.current_file:
            with open(self.current_file, "w") as f:
                f.write(self.text_area.get(1.0, tk.END))

    def run_script(self):
        self.save_script()
        if self.current_file:
            # Runs your main.py which loads the saved user script internally
            subprocess.Popen(["python", "main.py"])


if __name__ == "__main__":
    root = tk.Tk()
    app = ScriptEditor(root)
    root.mainloop()
