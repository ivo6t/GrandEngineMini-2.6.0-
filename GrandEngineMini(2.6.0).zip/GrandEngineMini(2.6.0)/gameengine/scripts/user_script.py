# Write your script here
import pygame
from game_engine.core import all  # Assuming your engine is imported like this

# Setup
screen = all.window.CreateWindow(800, 600)
all.fps(60)

# Player
player_x, player_y = 400, 500
player_speed = 5
player_rect = pygame.Rect(player_x, player_y, 50, 50)

# Bullets
bullets = []
bullet_speed = 10

# Enemies
enemies = []
enemy_spawn_timer = 0

# Score
score = 0
font = pygame.font.SysFont("Arial", 24)

def update():
    global player_x, player_y, enemy_spawn_timer, score
    
    # Input
    all.input.get()
    if all.input.left(): player_x -= player_speed
    if all.input.right(): player_x += player_speed
    if all.input.up(): player_y -= player_speed
    if all.input.down(): player_y += player_speed
    
    # Keep player on screen
    player_x = max(0, min(player_x, 750))
    player_y = max(0, min(player_y, 550))
    player_rect.topleft = (player_x, player_y)
    
    # Shooting (SPACE to fire)
    if all.keys[pygame.K_SPACE] and len(bullets) < 3:
        bullets.append(pygame.Rect(player_x + 20, player_y, 10, 20))
    
    # Move bullets
    for bullet in bullets[:]:
        bullet.y -= bullet_speed
        if bullet.y < 0:
            bullets.remove(bullet)
    
    # Spawn enemies
    enemy_spawn_timer += 1
    if enemy_spawn_timer >= 60:
        enemies.append(pygame.Rect(100, 0, 40, 40))
        enemy_spawn_timer = 0
    
    # Move enemies
    for enemy in enemies[:]:
        enemy.y += 3
        if enemy.y > 600:
            enemies.remove(enemy)
        
        # Collision: Bullet -> Enemy
        for bullet in bullets[:]:
            if enemy.colliderect(bullet):
                bullets.remove(bullet)
                enemies.remove(enemy)
                score += 10
                break
    
    # Draw everything
    all.screen.clear(screen, all.colors.blue())
    all.shapes.rect(screen, all.colors.yellow(), player_x, player_y, 50, 50)
    
    for bullet in bullets:
        all.shapes.rect(screen, all.colors.green(), bullet.x, bullet.y, bullet.width, bullet.height)
    
    for enemy in enemies:
        all.shapes.rect(screen, all.colors.red(), enemy.x, enemy.y, enemy.width, enemy.height)
    
    # Draw score
    score_text = font.render(f"Score: {score}", True, (255, 255, 255))
    all.Img.img_r(screen, score_text, 10, 10)

# Start the game!
all.window.window_start(update)
all.window.window_close()
