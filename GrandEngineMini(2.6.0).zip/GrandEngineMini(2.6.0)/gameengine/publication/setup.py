from setuptools import setup, find_packages

setup(
    name='easy_gameengine',
    version='0.1.0',
    description='Simple Python game engine based on pygame',
    author='ivo',
    author_email='srfzf464@gmail.com',
    url='https://github.com/ivo6t/easy-gameengine',
    packages=find_packages(),
    install_requires=[
        'pygame>=2.0.0',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.7',
)
