# Easy GameEngine

A simple and lightweight Python game engine built on top of [pygame](https://www.pygame.org/), designed to help you create games quickly with easy-to-use drawing, input, sound, and image handling.

## Features

- Simple shape drawing (rectangles, circles)
- Easy color utilities
- Image loading and rendering
- Sound loading and playback
- Input helpers (keyboard)
- FPS control built-in

## Installation

You can install it via pip (coming soon on PyPI!):

```bash
pip install easy_gameengine
