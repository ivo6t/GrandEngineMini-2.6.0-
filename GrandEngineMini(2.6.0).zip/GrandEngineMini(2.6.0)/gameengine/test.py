from game_engine.core import *
from game_engine.colors import *
from game_engine.preBuild import *
from extensions.core_extensions.inputs_ext import *

HEIGHT = 700
WIDTH = 700
screen = GN.window.CreateWindow(WIDTH,HEIGHT)
speed = 3
player_size = 100
x,y = 300,300

def update():
    global x,y
    GN.input.get()               # get input states
    x,y = player.input.GNInput(x,y,speed)
    x,y = Border.border(x,y, player_size, WIDTH, HEIGHT)

    GN.screen.clear(screen, Colors.black())
    GN.shapes.rect(screen, Colors.cyan(), x, y, player_size, player_size)
GN.window.window_start(update)
GN.window.window_close()
