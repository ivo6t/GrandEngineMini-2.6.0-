# Grand Engine - Tutorial

Welcome to **Grand Engine**, your lightweight Python game engine built on top of Pygame! This tutorial will help you get started with the core features and extensions.

---

## Getting Started

### 1. Setup

Make sure you have Python and Pygame installed:

```bash
pip install pygame

Place the entire game_engine folder in your project directory.
Basic Usage
Creating a Window

Use GN.window.CreateWindow(width, height) to create a game window.

from game_engine.core import GN

WIDTH, HEIGHT = 700, 700
screen = GN.window.CreateWindow(WIDTH, HEIGHT)

Drawing Shapes

Draw rectangles and circles with GN.shapes:

GN.shapes.rect(screen, GN.colors.red(), 50, 50, 100, 100)
GN.shapes.circ(screen, GN.colors.blue(), 200, 200, 50)

Handling Input

Update key states each frame:

keys = GN.input.get()

Check for key presses (WASD or arrows):

if GN.input.up():
    # move up
if GN.input.left():
    # move left

Moving a Player

Use preBuild.py's player input helper:

from game_engine.preBuild import player

x, y = 100, 100
speed = 5

# Inside your game loop
x, y = player.input.GNInput(x, y, speed)

Playing Sounds

Load and play sounds from the assets folder:

sound = GN.Sound.load("jump.wav")
GN.Sound.play(sound)

Using Extensions
Jump and Run Controls

from game_engine.core_extensions.inputs_ext import Input, Player

p = Player(100, 100)
Input.jump(p, 50)         # Jump height 50 pixels
Input.running(p, 5)       # Speed 5 pixels per frame

Collision Detection

from game_engine.core import Collision

player_collider = Collision(100, 100, 50, 50)
enemy_collider = Collision(150, 150, 50, 50)

if player_collider.collision(enemy_collider):
    print("Collision detected!")

Border Limits

Keep player inside screen boundaries:

from game_engine.core import Border

x, y = Border.border(x, y, player_size=50, WIDTH=700, HEIGHT=700)

Running the Main Window Loop

def game_code():
    # Your game update and draw code here
    pass

GN.window.window_start(game_code)
GN.window.window_close()

Notes

    All assets (images, sounds) must be placed inside the assets folder.

    Customize fonts with GN.text.set_font(font_name, size).

    The engine runs at 60 FPS by default using GN.fps(60).

Final Words

Thanks for using Grand Engine!
Keep creating and pushing your game dev skills to the max.
If you get stuck, just take a deep breath and keep coding — you got this! 🚀

Peace out, and happy game making! 🎮🔥
— ivo6t

🖤 Follow me on YouTube GrandEngine for simple tutorials, behind-the-scenes dev, and engine progress.

Love you guys. Thanks for the support. ❤️